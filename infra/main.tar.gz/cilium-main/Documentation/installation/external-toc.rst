.. only:: not (epub or latex or html)

    WARNING: You are looking at unreleased Cilium documentation.
    Please use the official rendered version released here:
    https://docs.cilium.io

.. _external_install_root:

External Installers
-------------------

.. toctree::
   :maxdepth: 2
   :glob:

   k8s-install-aks
   k8s-install-kops
   k8s-install-kubespray
   k8s-install-kubeadm
   k8s-install-rancher-existing-nodes
   k8s-install-rke
   rancher-desktop

